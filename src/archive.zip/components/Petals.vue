<template>
  <div class="petals-container" ref="petalsContainer"></div>
</template>

<script setup>
import { onMounted, ref } from 'vue';

const petalsContainer = ref(null);

const createPetal = () => {
  if (!petalsContainer.value) return;
  
  const petal = document.createElement('div');
  petal.classList.add('petal');
  
  const size = Math.random() * 8 + 4;
  const startX = Math.random() * window.innerWidth;
  const duration = Math.random() * 15 + 10;
  const delay = Math.random() * 10;
  
  petal.style.width = `${size}px`;
  petal.style.height = `${size}px`;
  petal.style.left = `${startX}px`;
  petal.style.animationDuration = `${duration}s`;
  petal.style.animationDelay = `-${delay}s`;
  petal.style.opacity = Math.random() * 0.4 + 0.2;
  
  petalsContainer.value.appendChild(petal);
  
  setTimeout(() => {
    if (petal.parentNode) {
      petal.remove();
      createPetal();
    }
  }, duration * 1000);
};

onMounted(() => {
  for (let i = 0; i < 35; i++) {
    setTimeout(createPetal, Math.random() * 5000);
  }
});
</script>

<style scoped>
.petals-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 5;
  pointer-events: none;
}

:deep(.petal) {
  position: absolute;
  background: linear-gradient(to bottom right, #fff5f8, #ffd1dc);
  border-radius: 150% 0 150% 0;
  opacity: 0.7;
  transform-origin: center;
  animation: fall linear infinite;
}

@keyframes fall {
  0% {
    transform: translate(0, -10%) rotate(0deg) skew(0deg);
  }
  100% {
    transform: translate(200px, 110vh) rotate(1080deg) skew(30deg);
  }
}
</style>
