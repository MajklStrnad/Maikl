<template>
  <div class="gallery-page">
    <canvas ref="bgCanvas" class="bg-canvas"></canvas>

    <header class="gallery-head">
      <p class="eyebrow">Selected Work</p>
      <h1>Gallery</h1>
      <p class="sub">A collection of past builds — get in touch if you'd like to see more.</p>
    </header>

    <div class="fan-wrap" @mouseenter="fanOpen = true" @mouseleave="fanOpen = false; hovered = null">
      <div
        v-for="(item, i) in projects"
        :key="item.id"
        class="proj-card"
        :style="cardStyle(i)"
        tabindex="0"
        role="button"
        :aria-label="`${item.title} — ${item.category}`"
        @mouseenter="hovered = i"
        @focus="fanOpen = true; hovered = i"
        @blur="if (hovered === i) { fanOpen = false; hovered = null }"
      >
        <div class="proj-thumb" :style="{ background: item.gradient }">
          <span class="proj-index">{{ String(i + 1).padStart(2, '0') }}</span>
          <span class="proj-sheen"></span>
        </div>

        <div class="proj-info">
          <p class="proj-cat">{{ item.category }}</p>
          <h3 class="proj-title">{{ item.title }}</h3>
          <span class="proj-link">View project →</span>
        </div>
      </div>
    </div>

    <p class="fan-hint" :class="{ hidden: fanOpen }">Hover to explore</p>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

// Filler content — swap `gradient` for real project thumbnails later,
// and wire proj-link up to actual case study routes/URLs.
const projects = [
  { id: 1, title: 'Nocturne', category: 'Web App',    gradient: 'linear-gradient(150deg, #1a1a1a, #2a1620)' },
  { id: 2, title: 'Verdant',  category: 'E-commerce', gradient: 'linear-gradient(150deg, #181818, #241a22)' },
  { id: 3, title: 'Halcyon',  category: 'Portfolio',  gradient: 'linear-gradient(150deg, #1c1c1c, #2c1922)' },
  { id: 4, title: 'Monogram', category: 'Branding',   gradient: 'linear-gradient(150deg, #171717, #221720)' },
  { id: 5, title: 'Ledger',   category: 'Dashboard',  gradient: 'linear-gradient(150deg, #1a1a1a, #271a24)' },
]

// ── Fan-out deck ─────────────────────────────────────────────────
// At rest the cards sit in a tight, slightly-tilted stack (like a closed
// hand of cards). Hovering — or, for keyboard users, focusing a card via
// Tab — spreads them into an arc; the active card lifts in front of its
// neighbors with extra shadow depth so the stacking reads as solid, not flat.
const fanOpen = ref(false)
const hovered = ref(null)

const CENTER = (projects.length - 1) / 2 // 2, for 5 cards

function cardStyle(i) {
  const offset = i - CENTER
  const angle  = fanOpen.value ? offset * 13 : offset * 5
  const x      = fanOpen.value ? offset * 150 : offset * 20
  const isHovered = hovered.value === i
  const y      = fanOpen.value ? (isHovered ? -48 : -12) : 0
  const scale  = fanOpen.value && isHovered ? 1.07 : 1
  const z      = isHovered ? 20 : 10 - Math.abs(offset)

  const shadow = isHovered
    ? '0 32px 60px rgba(0, 0, 0, 0.55), 0 0 0 1px rgba(255, 192, 203, 0.15), 0 0 40px rgba(255, 192, 203, 0.12)'
    : fanOpen.value
      ? '0 18px 34px rgba(0, 0, 0, 0.45)'
      : `0 ${6 + Math.abs(offset) * 2}px ${16 + Math.abs(offset) * 4}px rgba(0, 0, 0, 0.4)`

  return {
    transform: `translate(-50%, 0) translate(${x}px, ${y}px) rotate(${angle}deg) scale(${scale})`,
    zIndex: z,
    boxShadow: shadow,
    transition: 'transform 0.65s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.4s ease, border-color 0.3s ease',
  }
}

// ── Ambient background: drifting sakura petals in pseudo-3D depth ──────
// Points have real x/y/z coordinates; each frame z decreases (petals drift
// toward the viewer) and screen position is a perspective projection, so
// nearer petals are bigger, brighter, and move faster across the screen —
// genuine parallax depth from a 2D canvas, no WebGL/three.js dependency.
const bgCanvas = ref(null)

onMounted(() => {
  const canvas = bgCanvas.value
  const ctx = canvas.getContext('2d')

  const FOV = 300
  const DEPTH = 900
  const COUNT = 90
  const SPEED = 1.1

  let w = 0, h = 0
  let mouseX = 0, mouseY = 0 // -1..1, smoothed
  let targetMouseX = 0, targetMouseY = 0

  function resize() {
    w = canvas.width = canvas.offsetWidth
    h = canvas.height = canvas.offsetHeight
  }
  resize()
  window.addEventListener('resize', resize)

  function onMouseMove(e) {
    targetMouseX = (e.clientX / window.innerWidth) * 2 - 1
    targetMouseY = (e.clientY / window.innerHeight) * 2 - 1
  }
  window.addEventListener('mousemove', onMouseMove)

  const petals = Array.from({ length: COUNT }, () => spawn(true))

  function spawn(initial = false) {
    return {
      x: (Math.random() * 2 - 1) * w,
      y: (Math.random() * 2 - 1) * h,
      z: initial ? Math.random() * DEPTH : DEPTH,
      r: 6 + Math.random() * 10,
      hue: Math.random() < 0.5 ? '255,192,203' : '255,218,224', // pink / pale pink
      drift: (Math.random() - 0.5) * 0.4,
    }
  }

  let rafId
  function draw() {
    mouseX += (targetMouseX - mouseX) * 0.05
    mouseY += (targetMouseY - mouseY) * 0.05

    ctx.clearRect(0, 0, w, h)
    const cx = w / 2 + mouseX * 40
    const cy = h / 2 + mouseY * 30

    // sort back-to-front so nearer petals draw over farther ones
    petals.sort((a, b) => b.z - a.z)

    for (const p of petals) {
      p.z -= SPEED
      p.x += p.drift
      if (p.z <= 1) Object.assign(p, spawn(false))

      const scale = FOV / p.z
      const sx = cx + p.x * scale * 0.6
      const sy = cy + p.y * scale * 0.6
      const size = p.r * scale * 0.35
      const depthFade = 1 - p.z / DEPTH

      if (sx < -50 || sx > w + 50 || sy < -50 || sy > h + 50 || size < 0.2) continue

      const alpha = Math.min(depthFade * 0.55, 0.5)
      ctx.beginPath()
      ctx.ellipse(sx, sy, size, size * 0.7, Math.PI / 4, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(${p.hue},${alpha})`
      ctx.shadowColor = `rgba(${p.hue},${alpha})`
      ctx.shadowBlur = size * 1.5
      ctx.fill()
    }
    ctx.shadowBlur = 0

    rafId = requestAnimationFrame(draw)
  }
  draw()

  onUnmounted(() => {
    cancelAnimationFrame(rafId)
    window.removeEventListener('resize', resize)
    window.removeEventListener('mousemove', onMouseMove)
  })
})
</script>

<style scoped>
.gallery-page {
  position: relative;
  background: var(--bg-color);
  color: var(--text-color);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  min-height: 100vh;
  padding: 160px 40px 120px;
  overflow: hidden;
}

.bg-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  pointer-events: none;
}

.gallery-head {
  position: relative;
  z-index: 1;
  max-width: 1400px;
  margin: 0 auto 80px;
  text-align: center;
}
.eyebrow {
  font-size: 0.65rem;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  color: #ffd1dc;
  font-weight: 300;
  margin-bottom: 16px;
}
.gallery-head h1 {
  font-size: clamp(2.4rem, 7vw, 4rem);
  font-weight: 100;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  margin-bottom: 16px;
  margin-right: -0.3em; /* balance the letter-spacing so the heading looks centered */
}
.sub {
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.4);
  font-weight: 300;
}

.fan-wrap {
  position: relative;
  z-index: 1;
  max-width: 1400px;
  margin: 0 auto;
  height: 500px;
}

.proj-card {
  position: absolute;
  top: 0;
  left: 50%;
  width: 268px;
  transform-origin: bottom center;
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 10px;
  overflow: hidden;
  background: linear-gradient(160deg, #1a1a1a 0%, #121212 55%, #0b0b0b 100%);
  cursor: pointer;
  outline: none;
}
.proj-card:hover,
.proj-card:focus-visible {
  border-color: rgba(255, 192, 203, 0.4);
}
.proj-card:focus-visible {
  box-shadow: 0 0 0 2px rgba(255, 192, 203, 0.5), 0 32px 60px rgba(0, 0, 0, 0.55) !important;
}
.proj-card:active {
  transform-origin: bottom center;
  filter: brightness(0.96);
}

.proj-thumb {
  position: relative;
  height: 224px;
  overflow: hidden;
  display: flex;
  align-items: flex-end;
  padding: 18px;
}
.proj-sheen {
  position: absolute;
  inset: 0;
  background: linear-gradient(155deg, rgba(255, 255, 255, 0.06) 0%, transparent 40%),
              radial-gradient(circle at 85% 15%, rgba(255, 192, 203, 0.1), transparent 55%);
  pointer-events: none;
}

.proj-index {
  position: relative;
  z-index: 1;
  font-size: 0.7rem;
  letter-spacing: 0.2em;
  color: rgba(255, 255, 255, 0.3);
  font-weight: 400;
}

.proj-info {
  position: relative;
  z-index: 1;
  padding: 22px 24px 26px;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
}
.proj-cat {
  font-size: 0.6rem;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.35);
  margin-bottom: 8px;
}
.proj-title {
  font-size: 1.1rem;
  font-weight: 300;
  letter-spacing: 0.02em;
  color: var(--text-color);
  margin-bottom: 14px;
}
.proj-link {
  font-size: 0.65rem;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: #ffd1dc;
  opacity: 0;
  transform: translateX(-6px);
  transition: opacity 0.3s ease, transform 0.3s ease;
  display: inline-block;
}
.proj-card:hover .proj-link {
  opacity: 1;
  transform: translateX(0);
}

.fan-hint {
  position: relative;
  z-index: 1;
  text-align: center;
  margin-top: 24px;
  font-size: 0.62rem;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.25);
  transition: opacity 0.4s ease;
}
.fan-hint.hidden { opacity: 0; }

@media (max-width: 700px) {
  .gallery-page { padding: 130px 20px 80px; }
  .fan-wrap {
    height: auto;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }
  .proj-card {
    position: relative;
    top: auto; left: auto;
    width: 100%;
    transform: none !important;
  }
  .proj-thumb { height: 180px; }
  .fan-hint { display: none; }
}
</style>
